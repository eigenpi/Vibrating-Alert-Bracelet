package com.example.alex.vibrationalertbracelet;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.alex.vibrationalertbracelet.ui.connectionscreen.ConnectionScreenFragment;

public class ConnectionScreen extends AppCompatActivity {

    private String title;
    private int page;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.connection_screen_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, ConnectionScreenFragment.newInstance())
                    .commitNow();
        }
    }
}
