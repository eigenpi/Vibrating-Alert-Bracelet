package com.example.alex.vibrationalertbracelet.ui.connectionscreen;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.alex.vibrationalertbracelet.MainActivity;
import com.example.alex.vibrationalertbracelet.R;

import org.w3c.dom.Text;

public class ConnectionScreenFragment extends Fragment implements View.OnClickListener {

    private ConnectionScreenViewModel mViewModel;
    private Button alertTransferButton;
    public static ListView clientList;
    public static TextView disconnectText;

    public static ConnectionScreenFragment newInstance() {
        return new ConnectionScreenFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.connection_screen_fragment, container, false);
        //Start OnCreate stuff here
        alertTransferButton = view.findViewById(R.id.alertTransferButton);
        alertTransferButton.setOnClickListener(this);

        disconnectText = view.findViewById(R.id.disconnectText);
        disconnectText.setVisibility(View.INVISIBLE);
        clientList = view.findViewById(R.id.listView);

        //ArrayAdapter arrayAdapter = new ArrayAdapter<String>(this, R.layout.connection_screen_activity, exampleArray);
        clientList.setAdapter(MainActivity.arrayAdapter);

        //End OnCreate stuff
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(ConnectionScreenViewModel.class);
    }

    /*
     * Since there's only one button on this page, this just redirects the viewpager to the alert screen.
     */
    public void onClick(View view){
        MainActivity.displayAlertPage();
    }

    /*
     * Not currently used, originally was intended to display a message indicating that the
     * server couldn't be reached.
     */
    public static void showDisconnect(){
        try{
            disconnectText.setVisibility(View.VISIBLE);
        } catch(Exception e){

        }
    }
    public static void hideDisconnect(){
        try{
            disconnectText.setVisibility(View.INVISIBLE);
        } catch(Exception e){

        }
    }
}
