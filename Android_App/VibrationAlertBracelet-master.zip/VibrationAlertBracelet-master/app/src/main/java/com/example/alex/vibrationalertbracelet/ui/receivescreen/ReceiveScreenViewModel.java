package com.example.alex.vibrationalertbracelet.ui.receivescreen;

import android.arch.lifecycle.ViewModel;

public class ReceiveScreenViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
