package com.example.alex.vibrationalertbracelet;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ClientListAdapter extends ArrayAdapter {

    private Context context;
    private List<Client> clientList;
    private LayoutInflater inflater;

    private static class ViewHolder{
        TextView nameText;
        TextView roomText;
        ImageView statusImage;
    }

    public ClientListAdapter(Context context, List<Client> clientList){
        super(context, R.layout.listviewinput, clientList);
        this.context = context;
        this.clientList = clientList;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return clientList.size();
    }

    @Override
    public Object getItem(int position) {
        return clientList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        Client client = clientList.get(position);
        if (convertView == null) {

            viewHolder = new ViewHolder();
            convertView = inflater.inflate(R.layout.listviewinput, parent, false);
            viewHolder.nameText = (TextView) convertView.findViewById(R.id.clientNameText);
            viewHolder.roomText = (TextView) convertView.findViewById(R.id.roomNumberText);
            viewHolder.statusImage = (ImageView) convertView.findViewById(R.id.statusImage);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.nameText.setText(client.name);
        viewHolder.roomText.setText(client.room);
        if(client.connectionStatus.equals("CONNECTED")) viewHolder.statusImage.setImageResource(android.R.drawable.presence_online);
        else if(client.connectionStatus.equals("ALERT")) viewHolder.statusImage.setImageResource(android.R.drawable.presence_busy);
        else viewHolder.statusImage.setImageResource(android.R.drawable.presence_offline);

        return convertView;
    }

//    public void add(Client client){
//        clientList.add(client);
//        notifyDataSetChanged();
//    }

}
