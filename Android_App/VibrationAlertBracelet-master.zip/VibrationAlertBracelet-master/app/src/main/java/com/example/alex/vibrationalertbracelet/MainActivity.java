package com.example.alex.vibrationalertbracelet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.alex.vibrationalertbracelet.ui.alertscreen.AlertScreenFragment;
import com.example.alex.vibrationalertbracelet.ui.connectionscreen.ConnectionScreenFragment;
import com.example.alex.vibrationalertbracelet.ui.receivescreen.ReceiveScreenFragment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.channels.NotYetConnectedException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity{

    FragmentPagerAdapter adapter;
    private static CustomViewPager viewpager;
    private int mInterval = 5000;
    private Handler mHandler;

    public static ArrayAdapter arrayAdapter;
    private static ArrayList<String[]> clientList = new ArrayList<String[]>();
    private String clientInfo = "";
    private String[] splitClientInfo;
    private List<Client> clientNames = new ArrayList<>();
    private List<Client> previousClientState = new ArrayList<>();
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    public static String ipAddress = "192.168.42.1";
    public int portNumber = 43000;
    private boolean connectionError;


    /*
     * This pager adapter class is the custom adapter for the viewpager used to display different screens
     * and has a couple of functions to help with switching between fragments.
     */
    public static class pagerAdapter extends FragmentPagerAdapter {
        private static int NUM_ITEMS = 3;

        public pagerAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        // Returns total number of pages
        @Override
        public int getCount() {
            return NUM_ITEMS;
        }

        // Returns the fragment to display for that page
        @Override
        public Fragment getItem(int position) {
            switch (position) {
                case 0: // Fragment # 0 - This will show FirstFragment
                    return ConnectionScreenFragment.newInstance();
                case 1: // Fragment # 0 - This will show FirstFragment different title
                    return AlertScreenFragment.newInstance();
                case 2: // Fragment # 1 - This will show SecondFragment
                    return ReceiveScreenFragment.newInstance();
                default:
                    return null;
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewpager = findViewById(R.id.viewpager);
        adapter = new pagerAdapter(getSupportFragmentManager());
        viewpager.setAdapter(adapter);
        viewpager.setPagingEnabled(false);

        makeNotificationChannel("alert_notification","Vibration Alert Bracelet",NotificationManager.IMPORTANCE_HIGH);

        arrayAdapter = new ClientListAdapter(this, clientNames);
        mHandler = new Handler();
        startRepeatingTask();

    }

    /*
     * This method creates a notification channel for the device. Only called once on creation, after
     * which issueNotification is used to push notifications to the device.
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    void makeNotificationChannel(String id, String name, int importance) {
        NotificationChannel channel = new NotificationChannel(id, name, importance);
        channel.setShowBadge(true); // set false to disable badges, Oreo exclusive

        NotificationManager notificationManager =
                (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        channel.setLightColor(Color.RED);
        channel.enableLights(true);
        channel.setShowBadge(true);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        channel.enableVibration(true);

        notificationManager.createNotificationChannel(channel);
    }
    public void issueNotification(String alertContent) {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            makeNotificationChannel("alert_notification","VibrationAlertBracelet", NotificationManager.IMPORTANCE_HIGH);
//        }

        NotificationCompat.Builder notification = new NotificationCompat.Builder(this, "alert_notification");
        notification
                .setSmallIcon(R.drawable.ic_stat_name)
                .setContentTitle("VAB")
                .setContentText(alertContent)
                .setChannelId("alert_notification");

        NotificationManager notificationManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        assert notificationManager != null;
        notificationManager.notify(1, notification.build());
    }

    /*
     * This method just stops the constant server contacting when the app is closed.
     */
    @Override
    public void onDestroy() {
        super.onDestroy();
        stopRepeatingTask();
    }

    /*
     * This method is used to contact and update the listview's list of clients on a separate thread.
     */
    public void updateConnectionsList() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    getClientList();
                } catch (Exception e) {
                    e.printStackTrace();
//                    clientNames.clear();
//                    ConnectionScreenFragment.showDisconnect();
                }
            }
        });
        thread.start();
    }

    /*
     * This contacts the server and updates the listview list; this is called by the update method.
     */
    public void getClientList() {

        try {
            connectionError = false;
            socket = new Socket(ipAddress, portNumber);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            out.print("app");
            out.flush();

            out.print("UPDATE");
            out.flush();

            clientInfo = in.readLine();

            //socket.close();

        } catch (UnknownHostException e) {
            connectionError = true;
        } catch (IOException e) {
            connectionError = true;
        }

//        if(connectionError = false) {
        splitClientInfo = clientInfo.split(",");

        previousClientState.clear();
        for (Client client : clientNames) {
            previousClientState.add(new Client(client.name, client.room, client.connectionStatus));
        }

        clientNames.clear();

        int i = 0;
        String clientName = "";
        String clientRoom = "";
        String connectionStatus = "";

        for (String csvField : splitClientInfo) {
            switch (i) {
                case (0):
                    clientName = csvField;
                    i++;
                    break;

                case (1):
                    clientRoom = csvField;
                    i++;
                    break;

                case (2):
                    connectionStatus = csvField;
                    i = 0;
                    clientNames.add(new Client(clientName, clientRoom, connectionStatus));
                    break;
            }
        }

        //This for loop checks whether or not any of the bracelets have changed their alert status to
        // busy since the last check-in
        for (i = 0; i < clientNames.size(); i++) {
            if ((clientNames.get(i).connectionStatus.equals("ALERT")) && !(previousClientState.get(i).connectionStatus.equals("ALERT"))) {
                issueNotification("Bracelet alert received!");
            }
        }

        arrayAdapter.notifyDataSetChanged();
    }


    /*
     * These display methods can be called to swap the viewpager to the desired page.
     */
    public static void displayAlertPage() {
        //Shows the screen for the mass bracelet alert
        viewpager.setCurrentItem(1);
    }
    public static void displayConnectionsPage() {
        //Returns to the list of connected bracelets
        viewpager.setCurrentItem(0);
    }
    public static void displaySpecificInfoPage() {
        //Find the information on the selected bracelet, then display it
        viewpager.setCurrentItem(2);
    }

    /*
     * This Runnable controls the timer on the server updates, and updates the listview consistently
     */
    Runnable mStatusChecker = new Runnable() {
        @Override
        public void run() {
            try {
                updateConnectionsList();
            } finally {
                // 100% guarantee that this always happens, even if
                // your update method throws an exception
                mHandler.postDelayed(mStatusChecker, mInterval);
            }
        }
    };

    /*
     * These two methods just start and stop the repeating server updates.
     */
    void startRepeatingTask() {
        mStatusChecker.run();
    }
    void stopRepeatingTask() {
        mHandler.removeCallbacks(mStatusChecker);
    }
}
