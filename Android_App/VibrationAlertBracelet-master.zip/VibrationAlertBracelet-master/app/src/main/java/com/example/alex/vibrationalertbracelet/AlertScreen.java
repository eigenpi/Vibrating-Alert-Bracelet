package com.example.alex.vibrationalertbracelet;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.constraint.ConstraintLayout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

import com.example.alex.vibrationalertbracelet.ui.alertscreen.AlertScreenFragment;

public class AlertScreen extends AppCompatActivity {

    private String title;
    private int page;
    public final static String PREF_IP = "PREF_IP_ADDRESS";
    public static final int BLUE = (0xff0000ff);
    private Button alertButton;
    private EditText ipAddressBox;
    private ConstraintLayout homeLayout;
    SharedPreferences.Editor editor;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alert_screen_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, AlertScreenFragment.newInstance())
                    .commitNow();
        }
    }
}