package com.example.alex.vibrationalertbracelet;

public class Client {
    String name;
    String room;
    String connectionStatus;

    public Client(String name, String room, String connectionStatus){
        this.name = name;
        this.room = room;
        this.connectionStatus = connectionStatus;

    }
}
