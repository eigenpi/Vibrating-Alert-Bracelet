package com.example.alex.vibrationalertbracelet.ui.alertscreen;

import android.arch.lifecycle.ViewModel;

public class AlertScreenViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
