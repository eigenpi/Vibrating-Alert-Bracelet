package com.example.alex.vibrationalertbracelet.ui.connectionscreen;

import android.arch.lifecycle.ViewModel;

public class ConnectionScreenViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
