package com.example.alex.vibrationalertbracelet.ui.alertscreen;

import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.alex.vibrationalertbracelet.MainActivity;
import com.example.alex.vibrationalertbracelet.R;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.io.IOException;
import java.io.PrintWriter;

public class AlertScreenFragment extends Fragment implements View.OnClickListener {

    private AlertScreenViewModel mViewModel;
    private Button sendMassAlertButton;
    private Button cancelMassAlertButton;
    private Button backButton;
    private TextView alertStatus;
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    public static AlertScreenFragment newInstance() {
        return new AlertScreenFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.alert_screen_fragment, container, false);
        //Start here
        sendMassAlertButton = view.findViewById(R.id.massAlertButton);
        cancelMassAlertButton = view.findViewById(R.id.massAlertCancelButton);
        backButton = view.findViewById(R.id.backToConectionsButton);
        sendMassAlertButton.setOnClickListener(this);
        cancelMassAlertButton.setOnClickListener(this);
        backButton.setOnClickListener(this);

        alertStatus = view.findViewById(R.id.alertStatusText);
        //alertStatus.setVisibility(View.INVISIBLE);
        //End here
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(AlertScreenViewModel.class);
    }

    /*
     * This onClick method just determines which button is being pressed and calls the appropriate
     * method in response.
     */
    public void onClick(View view) {
        if(view.getId() == R.id.massAlertButton){
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try{
                        //alertStatus.setVisibility(View.VISIBLE);
                        massAlertButtonClick();
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            });
            thread.start();
        }
        else if(view.getId() == R.id.massAlertCancelButton){
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try{
                        cancelAlertButtonClick();
                        //alertStatus.setVisibility(View.INVISIBLE);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            });
            thread.start();
        }
        else if(view.getId() == R.id.backToConectionsButton) backButtonClick();
    }

    /*
     * Contacts the server and notifies it that bracelets should be alerted
     */
    public void massAlertButtonClick(){
//        String ipAddress = "192.168.42.1";      //insert IP address hardcoded here
        int portNumber = 43000;

        //Create socket connection
        try{
            socket = new Socket(MainActivity.ipAddress, portNumber);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            out.print("app");
            out.flush();

            out.print("SENDALERT");
            out.flush();

//            socket.close();
        }catch(UnknownHostException e) {
            e.printStackTrace();
            //System.exit(1);
        }catch(IOException e) {
            e.printStackTrace();
            //System.exit(1);
        }
    }

    /*
     * This just contacts the server and cancels any alerted statuses going to the bracelets (any
     * alerts from the bracelets will remain)
     */
    public void cancelAlertButtonClick(){
        int portNumber = 43000;

        //Create socket connection
        try{
            socket = new Socket(MainActivity.ipAddress, portNumber);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            out.print("app");
            out.flush();

            out.print("CANCELALERT");
            out.flush();

//            socket.close();
        }catch(UnknownHostException e) {
            e.printStackTrace();
            //System.exit(1);
        }catch(IOException e) {
            e.printStackTrace();
            //System.exit(1);
        }
    }

    /*
     * Just redirects the viewpager to the list of clients
     */
    public void backButtonClick(){
        MainActivity.displayConnectionsPage();
    }
}

